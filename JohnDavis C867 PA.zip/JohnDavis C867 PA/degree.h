#pragma once
#include <string>
enum Degree {SECURITY,NETWORKING,SOFTWARE};

static const std::string degreeTypeStrings[] = { "SECURITY", "NETWORKING", "SOFTWARE" };
